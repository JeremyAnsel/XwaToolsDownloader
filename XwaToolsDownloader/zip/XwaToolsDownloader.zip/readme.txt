
XwaToolsDownloader runs on Windows 32/64 bits with the .NET framework 4.5.
(Windows Vista, Windows 7, Windows 8, or superior)

# Usage

1) Run XwaToolsDownloader.exe.

2) It will download the tools list ( "xwa_tools_list.txt" ) from GitHub. To redownload the list, delete the "xwa_tools_list.txt" file.

3) It will create a directory named "_archives" and download the tools into this directory. Only the new tools are downloaded.

4) It will extract the tools. Only the new tools are extracted.
