
XwaToolsDownloader runs on Windows 32/64 bits with the .NET framework 4.8.
(Windows 7, Windows 8, Windows 10, Windows 11 or superior)

# Usage

1) Run XwaToolsDownloader.exe.

2) It will download the tools list ( "xwa_tools_list.txt" ) from GitHub.

3) It will create a directory named "_archives" and download the tools into this directory.

4) It will extract the tools. A warning will be shown if a tool directory already exist.
